package com.dany.util;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class Messages {
	//资源名称
	private static final String BUNDLE_NAME = "com.dany.properties.helloworld1";
	//绑定资源
	private static final ResourceBundle RESOURCEBUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);
	
	public static String getString(String key){
		return RESOURCEBUNDLE.getString(key);
	}
	
	public static String getString(String key, Object...params){
		String value = RESOURCEBUNDLE.getString(key);
		return MessageFormat.format(value, params);
	}
	
	public static void main(String[] args){
		System.out.println(getString("hello"));
//		System.out.println(getString("hello","10.10.74.251","zh_CN","中文"));
	}
}
