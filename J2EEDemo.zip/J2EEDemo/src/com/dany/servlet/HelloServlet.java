package com.dany.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.dany.bean.UserInfo;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.TypeHost;

/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	/*资源注射通过注解来完成*/
	/*private @Resource(name="hello")String helloParam;*/
	@Resource(name="hello")
	private String helloParam;
       
    public HelloServlet() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("construtor");
    }

   

	@Override
	public void init() throws ServletException {
		System.err.println("init");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// 使用 GBK 设置中文正常显示
		//ServletConfig sConfig = getServletConfig();
		String message = this.getServletConfig().getInitParameter("message10");
System.out.println("message = "+message);
System.out.println("helloParam = "+helloParam);
		String allowFileTypeParam = this.getServletConfig().getServletContext().getInitParameter("allowed file type");
System.out.println("allowFileTypeParam = "+allowFileTypeParam);
/*System.out.println("contextParam = "+contextParam);*/

		HttpSession session = request.getSession(); 
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write("菜鸟教程：http://www.runoob.com");
		
		String requestURI = request.getRequestURI();
		String method = request.getMethod();
		
		response.setContentType("text/html");
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		
		List<UserInfo> userList = new ArrayList<UserInfo>();
		UserInfo userInfo = new UserInfo();
		userInfo.setName(name);
		userInfo.setPassword(password);
		userList.add(userInfo);
		
		UserInfo userInfo1 = new UserInfo();
		userInfo1.setName(name);
		userInfo1.setPassword(password);
		userList.add(userInfo1);
		
		request.setAttribute("userList", userList);
		request.getRequestDispatcher("/WEB-INF/result.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
		System.out.println("Destroy");
	}

}
